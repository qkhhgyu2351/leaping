"use strict";var d=(a,r,o)=>new Promise((x,n)=>{var l=s=>{try{i(o.next(s))}catch(u){n(u)}},t=s=>{try{i(o.throw(s))}catch(u){n(u)}},i=s=>s.done?x(s.value):Promise.resolve(s.value).then(l,t);i((o=o.apply(a,r)).next())});const e=require("../../taro.js"),c=require("../../common.js");require("../../babelHelpers.js");require("../../vendors.js");const m=()=>{const[a,r]=e.reactExports.useState(null),o=[{id:1,account:"finance",accountName:"有二财经",content:`以前要3个会计凑2天的合并报表，现在大模型10分钟跑完初稿，还能标记出5个异常往来款。

不是AI取代会计，是会用AI的会计取代不会用的。

财务人，你准备好了吗？`,quote:"AI不是来抢饭碗的，是来递梯子的",type:"方法论"},{id:2,account:"finance",accountName:"有二财经",content:`一个上市公司老板说：我用AI财务系统，1年省了200万财务成本。

这200万不是裁员来的，是效率提升来的。

同样的工作，以前要10个人，现在3个人就够了。

AI降本增效，不是口号，是算出来的。`,quote:"AI的账，从来都不是人算出来的",type:"解决方案"},{id:3,account:"guest",accountName:"有二会客",content:`我从企业高管辞职做自媒体，用了AI工具，1个人干出5个人的活。

写作用Claude，生图用即梦，做视频用剪映。

不是AI取代人，是用AI的人取代不用AI的人。`,quote:"AI是你能力的放大器，不是替代品",type:"认识论"},{id:4,account:"guest",accountName:"有二会客",content:`一个财务朋友说：以前每天加班到9点，现在用AI工具，6点就下班了。

不是工作少了，是效率高了。

AI不是让你少工作，是让你多创造价值。

时代在变，你不变，就会被淘汰。`,quote:"AI时代，选择比努力更重要",type:"方法论"}],x=t=>d(exports,null,function*(){try{yield e.Taro.setClipboardData({data:t.content}),r(t.id),e.Taro.showToast({title:"已复制到剪贴板",icon:"success"}),setTimeout(()=>r(null),2e3)}catch(i){e.Taro.showToast({title:"复制失败",icon:"none"})}}),n=t=>t==="finance"?"#1B3A6B":"#3B4C7D",l=t=>t==="finance"?"#E8F4FD":"#3B4C7D";return e.jsxRuntimeExports.jsxs(e.View,{className:"min-h-screen bg-gray-50",children:[e.jsxRuntimeExports.jsxs(e.View,{className:"p-4 bg-white mb-4",children:[e.jsxRuntimeExports.jsx(e.Text,{className:"block text-lg font-bold mb-2",children:"朋友圈文案库"}),e.jsxRuntimeExports.jsx(e.Text,{className:"block text-sm text-gray-600",children:"点击“复制”按钮，一键复制文案内容"})]}),e.jsxRuntimeExports.jsx(e.View,{className:"px-4 pb-8",children:o.map(t=>e.jsxRuntimeExports.jsxs(c.Card,{className:"mb-4",children:[e.jsxRuntimeExports.jsx(c.CardHeader,{children:e.jsxRuntimeExports.jsx(e.View,{className:"flex justify-between items-center mb-2",children:e.jsxRuntimeExports.jsxs(e.View,{className:"flex items-center gap-2",children:[e.jsxRuntimeExports.jsx(e.Text,{className:"block text-sm font-bold px-2 py-1 rounded",style:{backgroundColor:l(t.account),color:t.account==="guest"?"#fff":"#1B3A6B"},children:t.accountName}),e.jsxRuntimeExports.jsx(c.Badge,{variant:"outline",style:{color:n(t.account),borderColor:n(t.account)},children:t.type})]})})}),e.jsxRuntimeExports.jsxs(c.CardContent,{children:[e.jsxRuntimeExports.jsx(e.View,{className:"p-3 rounded-lg mb-3",style:{backgroundColor:"#f5f5f5"},children:e.jsxRuntimeExports.jsx(e.Text,{className:"block text-sm leading-relaxed text-gray-800",children:t.content})}),e.jsxRuntimeExports.jsxs(e.View,{className:"mb-3",children:[e.jsxRuntimeExports.jsx(e.Text,{className:"block text-xs text-gray-500 mb-1",children:"金句"}),e.jsxRuntimeExports.jsxs(e.Text,{className:"block text-sm font-medium italic",style:{color:n(t.account)},children:["“",t.quote,"”"]})]}),e.jsxRuntimeExports.jsx(c.Button,{className:"w-full",onClick:()=>x(t),style:{backgroundColor:a===t.id?"#22C55E":n(t.account)},children:e.jsxRuntimeExports.jsx(e.Text,{className:"text-white text-sm font-medium",children:a===t.id?"✓ 已复制":"复制文案"})})]})]},t.id))})]})};var j={navigationBarTitleText:"文案库",navigationBarBackgroundColor:"#fff",navigationBarTextStyle:"black"};Page(e.createPageConfig(m,"pages/copywriting/index",{root:{cn:[]}},j||{}));
